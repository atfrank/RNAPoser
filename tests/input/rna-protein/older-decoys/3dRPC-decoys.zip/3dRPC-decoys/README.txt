1FJE: http://biophy.hust.edu.cn/3dRPC/result/499154297
2LUP: http://biophy.hust.edu.cn/3dRPC/result/820798789
2JPP: http://biophy.hust.edu.cn/3dRPC/result/744211473
3G9Y: http://biophy.hust.edu.cn/3dRPC/result/93895576